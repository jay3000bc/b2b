module.exports = {
  publicPath: "/mukesh/b2b/",
  runtimeCompiler: true,
  "transpileDependencies": [
    "vuetify"
  ]
}
